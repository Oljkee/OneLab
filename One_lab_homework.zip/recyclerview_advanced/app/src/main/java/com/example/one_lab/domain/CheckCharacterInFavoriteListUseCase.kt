package com.example.one_lab.domain

import com.example.one_lab.data.CharactersDto
import com.example.one_lab.data.Repository
import javax.inject.Inject

class CheckCharacterInFavoriteListUseCase @Inject constructor(
    private val repository: Repository
) {
    suspend fun invoke(id: Int): Boolean {
        return repository.checkCharacterInFavoriteList(id)
    }
}