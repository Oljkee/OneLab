package com.example.one_lab.data

import kotlinx.serialization.Serializable

data class CharactersDto(
    val info: InfoDto,
    val results: List<ResultDto>
)

data class InfoDto(
    val count: Int,
    val next: String?,
    val pages: Int,
    val prev: String?
)

@Serializable
data class ResultDto(
    val created: String,
    val episode: List<String>,
    val gender: String,
    val id: Int,
    val image: String,
    val location: LocationDto,
    val name: String,
    val origin: OriginDto,
    val species: String,
    val status: String,
    val type: String,
    val url: String
)

@Serializable
data class LocationDto(
    val name: String,
    val url: String
)

@Serializable
data class OriginDto(
    val name: String,
    val url: String
)