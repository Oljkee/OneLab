package com.example.one_lab.data

import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

private const val BASE_URL = "https://rickandmortyapi.com/"

interface RickandmortyApi {
    @GET("api/character")
    suspend fun getCharacters(
        @Query("page") page: Int
    ): CharactersDto
}

object RetrofitServices {
    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(MoshiConverterFactory.create())
        .build()

    val getCharactersData: RickandmortyApi = retrofit.create(RickandmortyApi::class.java)

}
