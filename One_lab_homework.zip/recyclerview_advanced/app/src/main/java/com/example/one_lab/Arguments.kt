package com.example.one_lab

object Arguments {
    const val CHARACTER = "CHARACTER"
    const val ALIVE_STATUS = "Alive"
    const val DEAD_STATUS = "Dead"
}