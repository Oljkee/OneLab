package com.example.one_lab.domain

import com.example.one_lab.data.Repository
import com.example.one_lab.data.entity.Character
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class GetFavoriteListUseCase @Inject constructor(
    private val repository: Repository
) {
    fun getCollectionList(): Flow<List<Character>> = repository.getFavoriteList()
}