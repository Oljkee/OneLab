package com.example.one_lab.presentation

import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.one_lab.Arguments
import com.example.one_lab.R
import com.example.one_lab.data.ResultDto
import com.example.one_lab.data.entity.Character
import com.example.one_lab.databinding.CharacterListItemBinding
import java.lang.StringBuilder

class CharacterPagingAdapter(
    private val onItemClick: (character: ResultDto) -> Unit
) :
    PagingDataAdapter<ResultDto, ResultDtoViewHolder>(ResultDtoDiffUtilCallback()) {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ResultDtoViewHolder {
        val binding =
            CharacterListItemBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        return ResultDtoViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ResultDtoViewHolder, position: Int) {
        val context = holder.binding.root.context
        val item = getItem(position)

        item?.apply {
            holder.binding.root.setOnClickListener {
                onItemClick(this)
            }

            val statusSpeciesText = StringBuilder()
                .append(status)
                .append(" - ")
                .append(species)
            holder.binding.apply {
                Glide.with(context)
                    .load(image)
                    .into(imgViewAvatar)

                textviewName.text = name
                textviewStatusSpecies.text = statusSpeciesText
                textviewLastLocation.text = location.name

                when (status) {
                    Arguments.ALIVE_STATUS -> {
                        viewDotStatus.visibility = View.VISIBLE
                        viewDotStatus.backgroundTintList =
                            ColorStateList.valueOf(context.getColor(R.color.green))
                    }

                    Arguments.DEAD_STATUS -> {
                        viewDotStatus.visibility = View.VISIBLE
                        viewDotStatus.backgroundTintList =
                            ColorStateList.valueOf(context.getColor(R.color.red))
                    }

                    else -> viewDotStatus.visibility = View.INVISIBLE
                }
            }

        }
    }
    }

class ResultDtoDiffUtilCallback : DiffUtil.ItemCallback<ResultDto>() {
    override fun areItemsTheSame(oldItem: ResultDto, newItem: ResultDto): Boolean =
        oldItem.id == newItem.id

    override fun areContentsTheSame(oldItem: ResultDto, newItem: ResultDto): Boolean =
        oldItem == newItem
}


class ResultDtoViewHolder(val binding: CharacterListItemBinding) :
    RecyclerView.ViewHolder(binding.root)
