package com.example.one_lab.presentation

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import com.example.one_lab.Arguments
import com.example.one_lab.R
import com.example.one_lab.data.ResultDto
import com.example.one_lab.data.entity.Character
import com.example.one_lab.databinding.FragmentCharacterItemBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import java.lang.StringBuilder

class CharacterItemFragment : Fragment() {

    private var _binding: FragmentCharacterItemBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()
    private lateinit var characterJson: String
    private lateinit var characterInfo: ResultDto

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCharacterItemBinding.inflate(layoutInflater, container, false)
        characterJson = arguments?.getString(Arguments.CHARACTER)!!
        characterInfo = characterJson.let {
            Json.decodeFromString(it)
        }
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
            val character = Character(characterInfo.id, characterJson)

            val type = if(characterInfo.type == "") "-" else characterInfo.type
            val characterInfo = StringBuilder()
                .append("name: ${characterInfo.name}\n")
                .append("status: ${characterInfo.status}\n")
                .append("species: ${characterInfo.species}\n")
                .append("type: $type\n")
                .append("gender: ${characterInfo.gender}\n")
                .append("origin: ${characterInfo.origin.name}\n")
                .append("location: ${characterInfo.location.name}\n")
                .append("created: ${characterInfo.created}\n")

            binding.apply {
                Glide.with(this@CharacterItemFragment)
                    .load(this@CharacterItemFragment.characterInfo.image)
                    .into(imgCharacterAvatar)

                textViewCharacterInfo.text = characterInfo

                viewLifecycleOwner.lifecycleScope.launch {
                    viewModel.inFavoriteList.collect { isCharacterInFavoriteList ->
                        if (isCharacterInFavoriteList) {
                            imgFavoriteIcon.setImageResource(R.drawable.ic_heart_checked)
                            textviewAddToFavorite.setText(R.string.delete_from_favorite)
                            linearLayoutAddToFavorite.setOnClickListener {
                                viewModel.deleteCharacterToFavoriteList(character)
                            }
                        }
                        else {
                            imgFavoriteIcon.setImageResource(R.drawable.ic_heart_unchecked)
                            textviewAddToFavorite.setText(R.string.add_to_favorite)
                            linearLayoutAddToFavorite.setOnClickListener {
                                viewModel.addCharacterToFavoriteList(character)
                            }
                        }

                    }
                }



                imgBackButton.setOnClickListener {
                    findNavController().popBackStack()
                }
            }

    }
}