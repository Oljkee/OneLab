package com.example.one_lab.presentation

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import androidx.paging.LoadState
import com.example.one_lab.databinding.FragmentMainBinding
import androidx.core.view.isVisible
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.example.one_lab.Arguments.CHARACTER
import com.example.one_lab.R
import com.example.one_lab.data.ResultDto
import com.example.one_lab.data.entity.Character
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@AndroidEntryPoint
class MainFragment : Fragment() {

    private var _binding: FragmentMainBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()
    private val characterPagingAdapter = CharacterPagingAdapter{character -> onCharacterListItemClick(character) }
    private val bundle = Bundle()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMainBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.apply {
            viewLifecycleOwner.lifecycleScope.launch {
                characterPagingAdapter.addLoadStateListener { loadState ->
                    val isListEmpty =
                        loadState.refresh is LoadState.NotLoading && characterPagingAdapter.itemCount == 0
                    recyclerView.isVisible = !isListEmpty
                    loadingProgressBar.isVisible = loadState.source.refresh == LoadState.Loading
                    val state = loadState.source.refresh is LoadState.Error
                    retryButton.isVisible = state
                    if(state) {
                        Toast.makeText(
                            context,
                            getString(R.string.loading_error),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    retryButton.setOnClickListener { characterPagingAdapter.retry() }
                }

                recyclerView.adapter = characterPagingAdapter.withLoadStateHeaderAndFooter(
                    header = CharacterLoadStateAdapter { characterPagingAdapter.retry() },
                    footer = CharacterLoadStateAdapter { characterPagingAdapter.retry() }
                )
                viewModel.characters.collectLatest {
                    characterPagingAdapter.submitData(it)
                }
            }
        }
    }

    private fun onCharacterListItemClick(character: ResultDto) {
        val characterJson = Json.encodeToString(character)
        bundle.putSerializable(CHARACTER, characterJson)
        viewModel.checkCharacterInFavoriteList(character.id)
        findNavController().navigate(
            R.id.action_mainFragment_to_characterItemFragment,
            bundle
        )
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}