package com.example.one_lab.domain

import com.example.one_lab.data.Repository
import com.example.one_lab.data.entity.Character
import javax.inject.Inject

class DeleteCharacterFromFavoriteListUseCase @Inject constructor(
    private val repository: Repository
) {
    suspend fun deleteCharacterFromFavoriteList(character: Character){
        repository.deleteCharacterFromFavoriteList(character)
    }
}