package com.example.one_lab

import android.content.Context
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.one_lab.data.CharactersDao
import com.example.one_lab.data.CharactersDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import javax.inject.Singleton


@InstallIn(SingletonComponent::class)
@Module
class ApplicationModule {

    @Provides
    fun provideCharacterDao(charactersDatabase: CharactersDatabase): CharactersDao {
        return charactersDatabase.charactersDao()
    }

    @Provides
    @Singleton
    fun ProvideCharacterDatabase(@ApplicationContext appContext: Context): CharactersDatabase {
        return runBlocking {
            buildDatabase(appContext)
        }
    }

    private suspend fun buildDatabase(context: Context): CharactersDatabase {
        return withContext(Dispatchers.IO) {
            Room.databaseBuilder(
                context,
                CharactersDatabase::class.java,
                "app-database.db"
            ).build()
        }
    }


}