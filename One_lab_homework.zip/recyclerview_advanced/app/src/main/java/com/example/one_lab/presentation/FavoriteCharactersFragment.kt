package com.example.one_lab.presentation

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardColors
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.isVisible
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.paging.LoadState
import com.bumptech.glide.integration.compose.ExperimentalGlideComposeApi
import com.bumptech.glide.integration.compose.GlideImage
import com.example.one_lab.Arguments
import com.example.one_lab.R
import com.example.one_lab.data.ResultDto
import com.example.one_lab.data.entity.Character
import com.example.one_lab.databinding.FragmentFavoriteCharactersBinding
import com.example.one_lab.databinding.FragmentMainBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.lang.StringBuilder

class FavoriteCharactersFragment : Fragment() {


//    private var _binding: FragmentFavoriteCharactersBinding? = null
//    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()
//    private val favoriteListAdapter = FavoriteListAdapter{ character -> onCharacterListItemClick(character) }
    private val bundle = Bundle()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
//        _binding = FragmentFavoriteCharactersBinding.inflate(layoutInflater, container, false)
//        return binding.root
        val view = ComposeView(requireContext())
        view.setContent {
            val state = viewModel.favoriteCharacterList.collectAsState()
//            FavoriteCharactersScreen(favoriteCharacters = state.value, onItemClick = onCharacterListItemClick(state))
            val favoriteCharacters = state.value
            if (favoriteCharacters.isNotEmpty()) {
                LazyColumn(
                    modifier = Modifier,
                    contentPadding = PaddingValues(5.dp)
                ) {
                    itemsIndexed(favoriteCharacters) { index, item ->
                        val characterInfo = item.characterJson.let {
                            Json.decodeFromString<ResultDto>(it)
                        }
                        CharacterListItem(characterInfo = characterInfo) {
                            onCharacterListItemClick(characterInfo)
                        }
                    }
                }
            } else {
                Text(
                    text = stringResource(id = R.string.empty_list),
                    fontSize = 25.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                        .wrapContentHeight(Alignment.CenterVertically),
                    textAlign = TextAlign.Center
                )
            }
        }
        return view
    }


//    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
//        super.onViewCreated(view, savedInstanceState)
//
//        binding.apply {
//            viewLifecycleOwner.lifecycleScope.launch {
//                binding.recyclerView.adapter = favoriteListAdapter
//                viewModel.favoriteCharacterList.collectLatest {
//                    if(it.isEmpty()) {
//                        recyclerView.visibility = View.GONE
//                        textViewEmptyList.visibility = View.VISIBLE
//                    } else {
//                        favoriteListAdapter.submitList(it)
//                        recyclerView.visibility = View.VISIBLE
//                        textViewEmptyList.visibility = View.GONE
//                    }
//                }
//            }
//        }
//    }

    private fun onCharacterListItemClick(character: ResultDto) {
        val characterJson = Json.encodeToString(character)
        bundle.putSerializable(Arguments.CHARACTER, characterJson)
        viewModel.checkCharacterInFavoriteList(character.id)
        findNavController().navigate(
            R.id.action_favoriteCharactersFragment_to_characterItemFragment,
            bundle
        )
    }

//    override fun onDestroyView() {
//        super.onDestroyView()
//        _binding = null
//    }
}


//@Composable
//fun FavoriteCharactersScreen(
//    favoriteCharacters: List<Character>,
//    modifier: Modifier = Modifier,
//    onItemClick: (ResultDto) -> Unit
//
//) {
//    if (favoriteCharacters.isNotEmpty()) {
//        LazyColumn(
//            modifier = modifier,
//            contentPadding = PaddingValues(5.dp)
//        ) {
//            itemsIndexed(favoriteCharacters) { index, item ->
//                CharacterListItem(item, FavoriteCharactersFragment.onCharacterListItemClick(item))
//            }
//        }
//    } else {
//        Text(
//            text = stringResource(id = R.string.empty_list),
//            fontSize = 25.sp,
//            fontWeight = FontWeight.Bold,
//            modifier = Modifier
//                .fillMaxSize()
//                .padding(16.dp)
//                .wrapContentHeight(Alignment.CenterVertically),
//            textAlign = TextAlign.Center
//        )
//    }
//}

@OptIn(ExperimentalGlideComposeApi::class)
@Composable
fun CharacterListItem(
    characterInfo: ResultDto,
    onItemClick: (ResultDto) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onItemClick(characterInfo) },
        shape = RoundedCornerShape(5.dp),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        ),
        colors = CardDefaults.cardColors(
            containerColor = Color.Gray,
        )
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            GlideImage(
                model = characterInfo.image,
                contentDescription = null,
                modifier = Modifier.size(64.dp)
            ) {
                it.error(R.drawable.ic_launcher_foreground)
                    .placeholder(R.drawable.ic_launcher_background)
                    .load(characterInfo.image)
            }

            Column(
                modifier = Modifier
                    .padding(start = 16.dp)
                    .weight(1f)
            ) {
                Text(
                    text = characterInfo.name,
                    style = TextStyle(
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(getDotColor(characterInfo.status))
                    )

                    Text(
                        text = "${characterInfo.status} - ${characterInfo.species}",
                        style = TextStyle(
                            fontSize = 14.sp,
                            color = Color.White
                        ),
                        modifier = Modifier.padding(start = 8.dp)
                    )
                }

                Text(
                    text = stringResource(id = R.string.last_known_location),
                    style = TextStyle(
                        fontSize = 14.sp,
                        color = Color.LightGray
                    ),
                    modifier = Modifier.padding(top = 20.dp)
                )

                Text(
                    text = characterInfo.location.name,
                    style = TextStyle(
                        fontSize = 14.sp,
                        color = Color.White
                    ),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun getDotColor(status: String): Color {
    return when (status) {
        Arguments.ALIVE_STATUS -> Color.Green
        Arguments.DEAD_STATUS -> Color.Red
        else -> Color.Transparent
    }
}


