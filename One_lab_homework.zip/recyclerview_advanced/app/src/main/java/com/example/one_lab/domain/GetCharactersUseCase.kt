package com.example.one_lab.domain

import com.example.one_lab.data.CharactersDto
import com.example.one_lab.data.Repository
import javax.inject.Inject


class GetCharactersUseCase @Inject constructor(
    private val repository: Repository
) {
    suspend fun getCharacters(page: Int): CharactersDto {
        return repository.getCharacters(page)
    }
}
