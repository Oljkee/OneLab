package com.example.one_lab.data

import com.example.one_lab.data.entity.Character
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class Repository @Inject constructor(
    private val dao: CharactersDao
) {
    suspend fun getCharacters(page: Int) : CharactersDto {
        return RetrofitServices.getCharactersData.getCharacters(page)
    }

    suspend fun checkCharacterInFavoriteList(id: Int) : Boolean {
        val character = dao.checkCharacterInFavoriteList(id)
        return character != null
    }

    suspend fun addCharacterToFavoriteList(character: Character) {
        dao.insertCharacter(character)
    }

    suspend fun deleteCharacterFromFavoriteList(character: Character) {
        dao.deleteCharacter(character)
    }

    fun getFavoriteList(): Flow<List<Character>> = dao.getCharacterList()
}

