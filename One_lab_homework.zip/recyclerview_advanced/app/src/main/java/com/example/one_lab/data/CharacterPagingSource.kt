package com.example.one_lab.data

import androidx.paging.PagingSource
import androidx.paging.PagingState
import com.example.one_lab.domain.GetCharactersUseCase

class CharacterPagingSource(
    private val getCharactersUseCase: GetCharactersUseCase
) : PagingSource<Int, ResultDto>() {

    override fun getRefreshKey(state: PagingState<Int, ResultDto>): Int? {
        return state.anchorPosition?.let { anchorPosition ->
            state.closestPageToPosition(anchorPosition)?.prevKey?.plus(1)
                ?: state.closestPageToPosition(anchorPosition)?.nextKey?.minus(1)
        }
    }

    override suspend fun load(params: LoadParams<Int>): LoadResult<Int, ResultDto> {
        val page = params.key ?: FIRST_PAGE
        return kotlin.runCatching {
            val characters = getCharactersUseCase.getCharacters(page)
            characters
        }.fold(
            onSuccess = {
                LoadResult.Page(
                    data = it.results,
                    prevKey = if (it.info.prev == null) null else page - 1,
                    nextKey = if (it.info.next == null) null else page + 1
                )
            },
            onFailure = {
                LoadResult.Error(it)
            }
        )
    }

    companion object {
        const val FIRST_PAGE = 1
    }

}