package com.example.one_lab.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.example.one_lab.data.CharacterPagingSource
import com.example.one_lab.data.ResultDto
import com.example.one_lab.data.entity.Character
import com.example.one_lab.domain.AddCharacterToFavoriteListUseCase
import com.example.one_lab.domain.CheckCharacterInFavoriteListUseCase
import com.example.one_lab.domain.DeleteCharacterFromFavoriteListUseCase
import com.example.one_lab.domain.GetCharactersUseCase
import com.example.one_lab.domain.GetFavoriteListUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    private val getCharactersUseCase: GetCharactersUseCase,
    private val checkCharacterInFavoriteListUseCase: CheckCharacterInFavoriteListUseCase,
    private val getFavoriteListUseCase: GetFavoriteListUseCase,
    private val addCharacterToFavoriteListUseCase: AddCharacterToFavoriteListUseCase,
    private val deleteCharacterFromFavoriteListUseCase: DeleteCharacterFromFavoriteListUseCase
) : ViewModel() {

    private val _inFavoriteList = MutableStateFlow(false)
    val inFavoriteList = _inFavoriteList.asStateFlow()

    val characters: Flow<PagingData<ResultDto>> = Pager(
        config = PagingConfig(pageSize = 20),
        pagingSourceFactory = {
            CharacterPagingSource(getCharactersUseCase)
        }
    ).flow.cachedIn(viewModelScope)


    fun checkCharacterInFavoriteList(id: Int) {
        viewModelScope.launch {
            _inFavoriteList.value = checkCharacterInFavoriteListUseCase.invoke(id)
        }
    }

    fun addCharacterToFavoriteList(character: Character) {
        viewModelScope.launch {
            addCharacterToFavoriteListUseCase.invoke(character)
            _inFavoriteList.value = true
        }
    }

    fun deleteCharacterToFavoriteList(character: Character) {
        viewModelScope.launch {
            deleteCharacterFromFavoriteListUseCase.deleteCharacterFromFavoriteList(character)
            _inFavoriteList.value = false
        }
    }


    val favoriteCharacterList = getFavoriteListUseCase.getCollectionList()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )


}