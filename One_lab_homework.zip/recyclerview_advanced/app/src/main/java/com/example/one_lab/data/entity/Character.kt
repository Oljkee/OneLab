package com.example.one_lab.data.entity
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable


@Entity(
    tableName = "favorite_characters"
)
//@Serializable
data class Character(
    @PrimaryKey
    @ColumnInfo(name = "id")
    val id: Int,
    @ColumnInfo(name = "characterJson")
    val characterJson: String
//    @ColumnInfo(name = "name")
//    val name: String,
//    @ColumnInfo(name = "created")
//    val created: String,
//    @ColumnInfo(name = "gender")
//    val gender: String,
//    @ColumnInfo(name = "image")
//    val image: String,
//    @ColumnInfo(name = "location")
//    val location: String,
//    @ColumnInfo(name = "origin")
//    val origin: String,
//    @ColumnInfo(name = "species")
//    val species: String,
//    @ColumnInfo(name = "status")
//    val status: String,
//    @ColumnInfo(name = "type")
//    val type: String
)
