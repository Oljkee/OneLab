package com.example.one_lab.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.one_lab.data.entity.Character
import kotlinx.coroutines.flow.Flow

@Dao
interface CharactersDao {
    // добавление персонажа
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertCharacter(character: Character)

    // удаление персонажа
    @Delete
    suspend fun deleteCharacter(character: Character)

    // получить список всех персонажей
    @Query("SELECT * FROM favorite_characters")
    fun getCharacterList(): Flow<List<Character>>

    @Query("SELECT * FROM favorite_characters WHERE id = :id")
    suspend fun checkCharacterInFavoriteList(id: Int): Character?
}