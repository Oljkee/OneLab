package com.example.one_lab.domain

import com.example.one_lab.data.Repository
import com.example.one_lab.data.entity.Character
import javax.inject.Inject

class AddCharacterToFavoriteListUseCase @Inject constructor(
    private val repository: Repository
) {
    suspend fun invoke(character: Character){
        repository.addCharacterToFavoriteList(character)
    }
}