//package com.example.one_lab.presentation
//
//import android.content.res.ColorStateList
//import android.view.LayoutInflater
//import android.view.View
//import android.view.ViewGroup
//import androidx.recyclerview.widget.DiffUtil
//import androidx.recyclerview.widget.ListAdapter
//import androidx.recyclerview.widget.RecyclerView
//import com.bumptech.glide.Glide
//import com.example.one_lab.Arguments
//import com.example.one_lab.R
//import com.example.one_lab.data.ResultDto
//import com.example.one_lab.data.entity.Character
//import com.example.one_lab.databinding.CharacterListItemBinding
//import kotlinx.serialization.json.Json
//
//class FavoriteListAdapter (
//    private val onItemClick: (character: ResultDto) -> Unit
//) : ListAdapter<Character, CharacterViewHolder>(CharacterDiffUtilCallback()) {
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CharacterViewHolder {
//        val binding =
//            CharacterListItemBinding.inflate(
//                LayoutInflater.from(parent.context),
//                parent,
//                false
//            )
//        return CharacterViewHolder(binding)
//    }
//
//    override fun onBindViewHolder(holder: CharacterViewHolder, position: Int) {
//        val context = holder.binding.root.context
//        val item = getItem(position)
//
//        val characterInfo = item.characterJson.let {
//            Json.decodeFromString<ResultDto>(it)
//        }
//
//        characterInfo.apply {
//            holder.binding.root.setOnClickListener {
//                onItemClick(this)
//            }
//
//            val statusSpeciesText = StringBuilder()
//                .append(status)
//                .append(" - ")
//                .append(species)
//            holder.binding.apply {
//                Glide.with(context)
//                    .load(image)
//                    .into(imgViewAvatar)
//
//                textviewName.text = name
//                textviewStatusSpecies.text = statusSpeciesText
//                textviewLastLocation.text = location.name
//
//                when (status) {
//                    Arguments.ALIVE_STATUS -> {
//                        viewDotStatus.visibility = View.VISIBLE
//                        viewDotStatus.backgroundTintList =
//                            ColorStateList.valueOf(context.getColor(R.color.green))
//                    }
//
//                    Arguments.DEAD_STATUS -> {
//                        viewDotStatus.visibility = View.VISIBLE
//                        viewDotStatus.backgroundTintList =
//                            ColorStateList.valueOf(context.getColor(R.color.red))
//                    }
//
//                    else -> viewDotStatus.visibility = View.INVISIBLE
//                }
//            }
//
//        }
//    }
//}
//
//class CharacterDiffUtilCallback : DiffUtil.ItemCallback<Character>() {
//    override fun areItemsTheSame(oldItem: Character, newItem: Character): Boolean =
//        oldItem.id == newItem.id
//
//    override fun areContentsTheSame(oldItem: Character, newItem: Character): Boolean =
//        oldItem == newItem
//}
//
//
//class CharacterViewHolder(val binding: CharacterListItemBinding) :
//    RecyclerView.ViewHolder(binding.root)
